<?php 
include 'config/connection.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Data Penerima KIS</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/theme.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

  </head>
  <body role="document">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
			<a class="navbar-brand" href="#">Input Data</a>
			<a class="navbar-brand" href="klas.php">Klasifikasi</a>
			
        </div>
          <div id="navbar" class="navbar-collapse collapse">
          </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container theme-showcase" role="main">

    <button onclick="add()" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_krw">
    <i class="bi bi-plus"></i> Tambah Data</button>
      
		<div class="page-header">
        <h3>Tabel Data Latih</h3>
		</div>
		
      <div class="page-header"></div>
        <div class="row">
          <div class="col-md-12">
            <table class="table">
              <thead>
                <tr>
                <th scope="col">#</th>
                  <th scope="col">NIK</th>
                  <th scope="col">Usia</th>
                  <th scope="col">Pendidikan terakhir</th>
                  <th scope="col">Pekerjaan</th>
                  <th scope="col">Pendapatan</th>
                  <th scope="col">Tanggungan Anak</th>
                  <th scope="col">Terima KIS</th>
				          <th scope="col">Opsi</th>
                </tr>
              </thead>
              <tbody id="tb"></tbody>
            </table>
          </div>
        </div>
    </div>
	
    <div class="modal fade" id="modal_krw" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Modal title</h4>
		  </div>
		  <div class="modal-body">
			<form id="form">
        <input type="hidden"  id="kode" name="kode">
				<div class="mb-3">
					<label for="Nik" class="form-label">NIK</label>
					<input type="text" class="form-control" id="Nik" name="Nik" required placeholder="Masukan NIK" autocomplete="off">
				</div> 
				<div class="mb-3">
					<label for="Usia" class="form-label">Usia</label>
					<input type="text" class="form-control" id="Usia" name="Usia" required placeholder="Masukan Usia" autocomplete="off">
				</div>
        <div class="mb-3">
					<label for="PTerakhir" class="form-label">Pendidikan Terakhir</label>
					<input type="text" class="form-control" id="PTerakhir" name="PTerakhir" required placeholder="Masukan Pendidikan Terakhir" autocomplete="off">
				</div>
        <div class="mb-3">
					<label for="Pekerjaan" class="form-label">Pekerjaan</label>
					<input type="text" class="form-control" id="Pekerjaan" name="Pekerjaan" required placeholder="Masukan Pekerjaan" autocomplete="off">
				</div>
        <div class="mb-3">
					<label for="Pendapatan" class="form-label">Pendapatan</label>
					<input type="text" class="form-control" id="Pendapatan" name="Pendapatan" required placeholder="Masukan Pendapatan" autocomplete="off">
				</div>  
        <div class="mb-3">
					<label for="TAnak" class="form-label">Tanggungan anak</label>
					<input type="text" class="form-control" id="TAnak" name="TAnak" required placeholder="Masukan Tanggungan Anak" autocomplete="off">
				</div>
        <div class="mb-3">
					<label for="TKIS" class="form-label">Terima KIS</label>
					<input type="text" class="form-control" id="TKIS" name="TKIS" required placeholder="Masukan Terima KIS" autocomplete="off">
				</div>
			</form>
		  </div>
		  <div class="modal-footer">
			<button type="button" onclick="save()" class="btn btn-primary" >Save changes</button>
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  </div>
		</div>
	  </div>
	</div>
		
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>

    <script>

        var save_method;

        $(document).ready(function (){
            load();
        });

        function load(){
            $.ajax({
                url : "function/Idata.php?act=load",
                dataType: "TEXT",
                success: function(data){
                    $('#tb').html(data);
                },error: function (jqXHR, textStatus, errorThrown){
                    alert('Error hapus data');
                }
            });
        }

        function add(){
            save_method = 'add';
            $('#form')[0].reset();
            $('#modal_krw').modal('show');
            $('.modal-title').text('Tambah Data');
        }

        function save(){
			      if(save_method === 'add') {
                url = "function/Idata.php?act=tambah";
            } else {
                url = "function/Idata.php?act=edit";
            }

            
            $.ajax({
                url : url,
                type: "POST",
                data: $('#form').serialize(),
                dataType: "JSON",
                success: function(data){
                    alert(data.status);
                    $('#modal_krw').modal('hide');
                    load();
                },error: function (jqXHR, textStatus, errorThrown){
                    alert("Error simpan");
                }
            });
        }
		
		function ganti(id_nik)
    {
			save_method = 'update';
			$('#form')[0].reset(); // reset form on modals
			$('#modal_krw').modal('show'); // show bootstrap modal when complete loaded
			$('.modal-title').text('Edit Data'); // Set title to Bootstrap modal title
			
			//Ajax Load data from ajax
			$.ajax({
				url : "function/Idata.php?act=load_text&id="+id_nik,
				type: "POST",
				dataType: "JSON",
				success: function(data)
        {
          $('[name="kode"]').val(id_nik);
          $('[name="Nik"]').val(data.Nik);
					$('[name="Usia"]').val(data.Usia);
          $('[name="PTerakhir"]').val(data.PTerakhir);
          $('[name="Pekerjaan"]').val(data.Pekerjaan);
          $('[name="Pendapatan"]').val(data.Pendapatan);
          $('[name="TAnak]').val(data.TAnak);
          $('[name="TKIS]').val(data.TKIS);
					
				},error: function (jqXHR, textStatus, errorThrown){
					alert('Error get data');
				}
			});
		}

    function hapus(id_nik, nik){
      
      $.ajax({
          url : "function/Idata.php?act=hapus&id="+id_nik,
          dataType: "JSON",
          success: function(data){
            alert(data.status);
            load();
          },error: function (jqXHR, textStatus, errorThrown){
              alert('Error hapus data');
          }
      });
    }

    </script>

  </body>
</html>
