<?php
include '../config/connection.php';

if($_GET['act'] == 'tambah'){
    $nik = $_POST['Nik'];
    $usia = $_POST['Usia'];
    $pendidikan_terakhir = $_POST['PTerakhir'];
    $pekerjaan = $_POST['Pekerjaan'];
    $pendapatan = $_POST['Pendapatan'];
    $tanggungan_anak = $_POST['TAnak'];
    $terima_kis = $_POST['TKIS'];

    $query =  mysqli_query($con, "INSERT INTO penerima_kis VALUES('','$nik','$usia','$pendidikan_terakhir','$pekerjaan','$pendapatan','$tanggungan_anak','$terima_kis');");

    echo json_encode(array("status" => "Data tersimpan"));

}else if($_GET['act'] == 'edit'){
    $nik = $_POST['Nik'];
    $usia = $_POST['Usia'];
    $pendidikan_terakhir = $_POST['PTerakhir'];
    $pekerjaan = $_POST['Pekerjaan'];
    $pendapatan = $_POST['Pendapatan'];
    $tanggungan_anak = $_POST['TAnak'];
    $terima_kis = $_POST['TKIS'];

    $query =  mysqli_query($con, "UPDATE penerima_kis SET nik = '$nik', usia = '$usia', pendidikan_terakhir = '$pendidikan_terakhir', pekerjaan = '$pekerjaan', pendapatan = '$pendapatan',  terima_kis = '$terima_kis', where id_nik = '".$_POST['kode']."';");

    echo json_encode(array("status" => "Data terupdate"));
	
}else if($_GET['act'] == 'hapus'){
    
    $id = $_GET['id'];

    $query =  mysqli_query($con, "DELETE from penerima_kis where id_nik = '".$id."';");

    echo json_encode(array("status" => "Data terhapus"));
}
else if($_GET['act'] == 'load'){
    
    $string = '';

    $nomor = 1;
    $query = mysqli_query($con, "SELECT * FROM penerima_kis order by nik asc");
    while ($row = mysqli_fetch_assoc($query)) {
        $string .= '<tr>';
        $string .= '<th scope="row">'.$nomor.'</th>
                    <td>'.$row['nik'].'</td>
                    <td>'.$row['usia'].'</td>
                    <td>'.$row['pendidikan_terakhir'].'</td>
                    <td>'.$row['pekerjaan'].'</td>
                    <td>'.$row['pendapatan'].'</td>
                    <td>'.$row['tanggungan_anak'].'</td>
                    <td>'.$row['terima_kis'].'</td>
                    <td>
                        <button type="button" class="btn btn-success eb" onclick="ganti('."'".$row['id_nik']."'".')">Edit</button>
                        <button type="button" class="btn btn-danger hb" onclick="hapus('."'".$row['id_nik']."'".','."'".$row['nik']."'".')">Hapus</button>
                    </td>';
        $string .= '</tr>';

        $nomor++;
    }
    echo $string;

}
else if($_GET['act'] == 'load_text'){
	
    $query =  mysqli_query($conn, "select * from penerima_kis where nik = '".$_GET['id_nik']."';");
    $row = mysqli_fetch_array($query);

    
    echo json_encode(array("Nik" => $row['nik'], "Usia" => $row['usia'], "PTerakhir" => $row['pendidikan_terakhir'],"Pekerjaan" => $row['pekerjaan'], "Pendapatan" => $row['pendapatan'],"TAnak" => $row['tanggungan_anak'],"TKIS" => $row['terima_kis']));

    //cho json_encode(array("status" => $_GET['id']));
}
?>