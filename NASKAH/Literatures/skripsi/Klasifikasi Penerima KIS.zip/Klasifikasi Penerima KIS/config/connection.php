<?php

$con = mysqli_connect("localhost", "root", "", "train_kis");

 if(mysqli_connect_error()){
     echo 'Koneksi Gagal : ' . mysqli_connect_error();
}
?>