<?php
require 'naive.php';
$hasil = '';
//jika tombol submit ditekan
if(isset($_POST['submit'])){
    $data = [
        "usia" => $_POST['usia'],
        "pendidikan_terakhir" => $_POST['pendidikan_terakhir'],
        "pekerjaan" => $_POST['pekerjaan'],
        "pendapatan" => $_POST['pendapatan'],
        "tanggungan_anak" => $_POST['tanggungan_anak'],
        
    ];
    $hasil = posteriorProbability($data);

}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Klasifikasi Penerima KIS</title>

    <link rel="stylesheet" href="css/stylee.css">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/theme.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <script src="../../assets/js/ie8-responsive-file-warning.js"></script>
    <script src="js/ie-emulation-modes-warning.js"></script>
    <h3 class="content_title">Menerima KIS atau Tidak</h3>

  </head>
  <body role="document">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
              <a class="navbar-brand" href="Index.php">Input Data</a>
              <a class="navbar-brand" href="klas.php">Klasifikasi</a>        
            </div>
          <div id="navbar" class="navbar-collapse collapse"></div>
        </div>
    </nav>
    
      <!-- <h3>Penerima KIS atau Tidak</h3> -->
    <form action="" method="post">
      <label for="nik">Masukkan NIK</label>
      <input class="nik" type="text" placeholder="Masukkan NIK">
        <!-- <input type="text" name="nik" id="nik"> -->
</br>
</br>
        <label for="usia">Usia</label>
        <input type="text" name="usia" id="usia" placeholder="Masukkan Usia">
</br>
</br>        
        <label for="pendidikan_terakhir">Pendidikan Terakhir</label>
        <input type="text" name="pendidikan_terakhir" id="pendidikan_terakhir" placeholder="Masukkan Pendidikan Terakhir">
</br>
</br>

        <label for="pekerjaan">Pekerjaan</label>
        <input type="text" name="pekerjaan" id="pekerjaan" placeholder="Masukkan Pekerjaan">
</br>
</br> 
         
         <label for="pendapatan">Pendapatan</label>
         <input type="text" name="pendapatan" id="pendapatan" placeholder="Masukkan Pendapatan">
</br>
</br>
 
        <label for="tanggungan_anak">Tanggungan Anak</label>
        <input type="text" name="tanggungan_anak" id="tanggungan_anak" placeholder="Masukkan Jumlah Tanggungan Anak">
</br>
</br>
        <button class="btn btn-primary" type="submit" name="submit">Submit</button>
    </form>
</br>
    <!-- hasil-->
    <h4><strong>Terima KIS : <?= $hasil;?><strong></h4>
    
    
    

     <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>


  </body>
</html>

